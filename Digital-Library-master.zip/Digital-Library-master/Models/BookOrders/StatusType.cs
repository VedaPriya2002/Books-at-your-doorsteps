﻿namespace Library.Models.BookOrders
{
    public enum StatusType
    {
        To_be_borrowed=1,
        Borrowed=2,
        Returned=3
    }
}