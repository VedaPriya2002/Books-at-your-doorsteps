﻿namespace Library.Models
{
    public class RoleName
    {
        public string lib = "Librarian";
        public string mem = "Member";
    }
}